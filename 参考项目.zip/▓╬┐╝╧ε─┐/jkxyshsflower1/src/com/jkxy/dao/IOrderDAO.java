package com.jkxy.dao;

import com.jkxy.model.Orders;

public interface IOrderDAO {
	public Orders saveOrder(Orders order);
}
