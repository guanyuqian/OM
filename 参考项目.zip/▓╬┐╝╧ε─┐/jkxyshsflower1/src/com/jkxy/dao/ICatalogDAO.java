package com.jkxy.dao;

import java.util.List;

public interface ICatalogDAO {
public List getAllCatalogs();

}
