package com.jkxy.service;

import com.jkxy.model.Orders;


public interface IOrderService {
	public Orders saveOrder(Orders order);
}
