package com.jkxy.service;

import java.util.List;



public interface ICatalogService {
public List getAllCatalogs();

}
